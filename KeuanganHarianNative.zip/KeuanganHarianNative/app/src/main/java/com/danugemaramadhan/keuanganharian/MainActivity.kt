package com.danugemaramadhan.keuanganharian

import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.json.JSONArray
import org.json.JSONObject
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

private val Bg = Color(0xFF061713)
private val Panel = Color(0xFF0D211B)
private val Panel2 = Color(0xFF123229)
private val Lime = Color(0xFFB9FF3B)
private val Lime2 = Color(0xFF8FDB25)
private val Ink = Color(0xFFF7F9EF)
private val Muted = Color(0xFF9AA08C)
private val Red = Color(0xFFFF6572)
private val Blue = Color(0xFF78A6FF)
private val Yellow = Color(0xFFFFD84D)
private val Line = Color(0xFF24483D)

private data class Tx(val id: Long, val type: String, val desc: String, val amount: Long, val date: String)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent { AppTheme { FinanceApp(this) } }
    }
}

@Composable
private fun AppTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            background = Bg, surface = Panel, primary = Lime,
            onPrimary = Color(0xFF172000), onBackground = Ink, onSurface = Ink,
            surfaceVariant = Panel2, onSurfaceVariant = Muted, error = Red
        ),
        content = content
    )
}

@Composable
private fun FinanceApp(context: Context) {
    val store = remember { FinanceStore(context) }
    var tx by remember { mutableStateOf(store.load()) }
    var salary by remember { mutableLongStateOf(store.salary()) }
    var limit by remember { mutableLongStateOf(store.limit()) }
    var savings by remember { mutableLongStateOf(store.savings()) }
    var obligation by remember { mutableLongStateOf(store.obligation()) }
    var tab by rememberSaveable { mutableIntStateOf(0) }
    var showAdd by remember { mutableStateOf(false) }
    var addType by remember { mutableStateOf("expense") }

    fun persist(newTx: List<Tx>, newSalary: Long = salary, newLimit: Long = limit, newSavings: Long = savings, newObligation: Long = obligation) {
        tx = newTx
        salary = newSalary
        limit = newLimit
        savings = newSavings
        obligation = newObligation
        store.save(newTx, newSalary, newLimit, newSavings, newObligation)
    }

    Scaffold(
        containerColor = Bg,
        contentWindowInsets = WindowInsets(0, 0, 0, 0),
        bottomBar = {
            BottomPill(tab) { tab = it }
        }
    ) { pad ->
        Box(Modifier.fillMaxSize().padding(pad).background(Bg)) {
            when (tab) {
                0 -> HomeScreen(tx, salary, limit, savings, onQuick = { type -> addType = type; showAdd = true }, onOpen = { tab = it })
                1 -> TransactionsScreen(tx, onAdd = { addType = "expense"; showAdd = true }, onDelete = { id -> persist(tx.filterNot { it.id == id }) })
                else -> PortfolioScreen(tx, savings)
            }
        }
    }

    if (showAdd) {
        AddDialog(
            initialType = addType,
            onDismiss = { showAdd = false },
            onSave = { type, desc, amount ->
                val date = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
                val newTx = tx + Tx(System.currentTimeMillis(), type, desc, amount, date)
                val newObligation = if (type == "pay") maxOf(0L, obligation - amount) else obligation
                persist(newTx, obligation = newObligation)
                showAdd = false
                tab = 0
            }
        )
    }
}

@Composable
private fun BottomPill(selected: Int, onSelect: (Int) -> Unit) {
    Surface(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 13.dp, vertical = 10.dp),
        color = Color(0xE805140F), shape = RoundedCornerShape(32.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0x3322AA77)),
        tonalElevation = 0.dp, shadowElevation = 14.dp
    ) {
        Row(Modifier.height(66.dp), verticalAlignment = Alignment.CenterVertically) {
            PillItem("⌂", "Beranda", selected == 0) { onSelect(0) }
            PillItem("▤", "Transaksi", selected == 1) { onSelect(1) }
            PillItem("◈", "Portofolio", selected == 2) { onSelect(2) }
        }
    }
}

@Composable
private fun RowScope.PillItem(icon: String, label: String, selected: Boolean, onClick: () -> Unit) {
    Column(
        Modifier.weight(1f).fillMaxHeight().clickable { onClick() },
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text(icon, color = if (selected) Lime else Muted, fontSize = 20.sp)
        Text(label, color = if (selected) Lime else Muted, fontSize = 10.sp, fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal)
    }
}

@Composable
private fun HomeScreen(
    tx: List<Tx>, salary: Long, limit: Long, savings: Long,
    onQuick: (String) -> Unit, onOpen: (Int) -> Unit
) {
    val income = tx.filter { it.type == "income" }.sumOf { it.amount }
    val expense = tx.filter { it.type == "expense" }.sumOf { it.amount }
    val pay = tx.filter { it.type == "pay" }.sumOf { it.amount }
    val balance = income - expense - pay + savings
    val today = todayString()
    val todayExpense = tx.filter { it.date == today && it.type == "expense" }.sumOf { it.amount }
    val left = maxOf(0L, limit - todayExpense)
    val month = today.take(7)
    val mi = tx.filter { it.date.startsWith(month) && it.type == "income" }.sumOf { it.amount }
    val me = tx.filter { it.date.startsWith(month) && it.type == "expense" }.sumOf { it.amount }
    val net = mi - me
    val spentPct = (me.toDouble() / maxOf(mi, salary, 1L) * 100).toInt().coerceIn(0, 100)

    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 15.dp, end = 15.dp, top = 16.dp, bottom = 94.dp),
        verticalArrangement = Arrangement.spacedBy(15.dp)
    ) {
        item {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(43.dp).clip(CircleShape).background(Brush.linearGradient(listOf(Color(0xFF29351B), Color(0xFF11150F)))), contentAlignment = Alignment.Center) {
                    Text("₽", color = Lime, fontSize = 19.sp)
                }
                Spacer(Modifier.width(11.dp))
                Column(Modifier.weight(1f)) {
                    Text("Halo, Kak!", fontSize = 15.sp, fontWeight = FontWeight.Bold)
                    Text("Keuangan pribadi • Offline", color = Muted, fontSize = 10.sp)
                }
                TopRound("⌕")
                Spacer(Modifier.width(7.dp))
                TopRound("⚙")
            }
        }

        item {
            GlassCard(Modifier.fillMaxWidth(), RoundedCornerShape(26.dp)) {
                Column(Modifier.padding(horizontal = 19.dp, vertical = 20.dp)) {
                    Text("TOTAL SALDO", color = Muted, fontSize = 9.sp, fontWeight = FontWeight.SemiBold)
                    Text(formatRupiah(balance), fontSize = 35.sp, fontWeight = FontWeight.Bold, letterSpacing = (-1).sp)
                    Text("Gaji harian ${formatRupiah(salary)} • Batas ${formatRupiah(limit)} / hari", color = Color(0xFFBFC8AE), fontSize = 10.sp)
                }
            }
        }

        item { SectionHeader("Kartu Keuangan", "Lihat semua ↗") }
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FinanceMini("＋", "Pemasukan hari ini", salary, "Gaji harian", Lime, Modifier.weight(1f))
                FinanceMini("↘", "Pengeluaran hari ini", todayExpense, "Batas ${formatRupiah(limit)}", Red, Modifier.weight(1f))
                FinanceMini("◎", "Sisa boleh dipakai", left, if (left > 0) "Aman" else "Melewati batas", if (left > 0) Lime else Red, Modifier.weight(1f))
            }
        }

        item { SectionHeader("Aksi Cepat", "Tambah data", null) }
        item {
            val quicks = listOf(
                "＋" to "Pemasukan" to "income", "↘" to "Pengeluaran" to "expense",
                "⇄" to "Pelunasan" to "pay", "◈" to "Portofolio" to "portfolio",
                "▤" to "Transaksi" to "transactions", "◇" to "Kewajiban" to "transactions",
                "◌" to "Laporan" to "portfolio", "⚙" to "Pengaturan" to "portfolio"
            )
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                quicks.chunked(4).forEach { row ->
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        row.forEach { item ->
                            val icon = item.first.first
                            val label = item.first.second
                            val action = item.second
                            QuickButton(icon, label, Modifier.weight(1f)) {
                                if (action == "portfolio") onOpen(2)
                                else if (action == "transactions") onOpen(1)
                                else onQuick(action)
                            }
                        }
                    }
                }
            }
        }

        item { SectionHeader("Ringkasan Bulan Ini", month) }
        item {
            GlassCard(Modifier.fillMaxWidth(), RoundedCornerShape(20.dp)) {
                Row(Modifier.padding(10.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    MetricBox("Pemasukan", mi, Lime, Modifier.weight(1f))
                    MetricBox("Pengeluaran", me, Red, Modifier.weight(1f))
                    MetricBox("Laba Bersih", net, Blue, Modifier.weight(1f))
                }
            }
        }

        item { SectionHeader("Penggunaan Bulan Ini", "Detail") }
        item {
            GlassCard(Modifier.fillMaxWidth(), RoundedCornerShape(20.dp)) {
                Column(Modifier.padding(14.dp)) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Pengeluaran", fontSize = 10.sp)
                        Text("$spentPct%", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    }
                    Spacer(Modifier.height(8.dp))
                    Box(Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(20.dp)).background(Color(0xFF262D1E))) {
                        Box(Modifier.fillMaxWidth(spentPct / 100f).fillMaxHeight().clip(RoundedCornerShape(20.dp)).background(Lime))
                    }
                    Spacer(Modifier.height(7.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Terpakai ${formatRupiah(me)}", color = Muted, fontSize = 9.sp)
                        Text("Sisa ${formatRupiah(maxOf(0, mi - me))}", color = Muted, fontSize = 9.sp)
                    }
                }
            }
        }

        item { SectionHeader("Grafik Keuangan 7 Hari", "Lihat") }
        item {
            GlassCard(Modifier.fillMaxWidth(), RoundedCornerShape(20.dp)) {
                Column(Modifier.padding(12.dp)) {
                    LineChart(tx, Modifier.fillMaxWidth().height(225.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(13.dp)) {
                        LegendDot(Lime, "Saldo portofolio")
                    }
                }
            }
        }

        item { SectionHeader("Diagram Keuangan", "Detail") }
        item {
            GlassCard(Modifier.fillMaxWidth(), RoundedCornerShape(20.dp)) {
                Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    DonutChart(mi, me, pay, Modifier.size(132.dp))
                    Spacer(Modifier.width(18.dp))
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        LegendDot(Lime, "Pemasukan")
                        LegendDot(Red, "Pengeluaran")
                        LegendDot(Color(0xFF52665C), "Pelunasan")
                        Text(formatRupiah(maxOf(0, net)), fontSize = 15.sp, fontWeight = FontWeight.Bold)
                        Text("laba bersih", color = Muted, fontSize = 8.sp)
                    }
                }
            }
        }

        item { SectionHeader("Transaksi Terbaru", "Lihat semua ↗") }
        item {
            GlassCard(Modifier.fillMaxWidth(), RoundedCornerShape(20.dp)) {
                if (tx.isEmpty()) EmptyState("Belum ada transaksi.")
                else tx.sortedByDescending { it.id }.take(5).forEach { TransactionRow(it) }
            }
        }
    }
}

@Composable
private fun SectionHeader(title: String, action: String, onClick: (() -> Unit)? = null) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 3.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(title, fontSize = 14.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
        Text(action, color = Lime, fontSize = 10.sp, fontWeight = FontWeight.Bold, modifier = if (onClick != null) Modifier.clickable { onClick() } else Modifier)
    }
}

@Composable
private fun TopRound(text: String) {
    Box(Modifier.size(39.dp).clip(CircleShape).background(Color(0xB2122D27)), contentAlignment = Alignment.Center) { Text(text, fontSize = 17.sp) }
}

@Composable
private fun GlassCard(modifier: Modifier, shape: RoundedCornerShape, content: @Composable ColumnScope.() -> Unit) {
    Card(
        modifier = modifier,
        shape = shape,
        colors = CardDefaults.cardColors(containerColor = Panel),
        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0x2B77AB95))
    ) {
        Column(Modifier.background(Brush.linearGradient(listOf(Color(0xDD0F3029), Color(0xD8061915)))), content = content)
    }
}

@Composable
private fun FinanceMini(icon: String, title: String, amount: Long, sub: String, color: Color, modifier: Modifier) {
    GlassCard(modifier.heightIn(min = 105.dp), RoundedCornerShape(17.dp)) {
        Column(Modifier.padding(11.dp)) {
            Text(icon, color = color, fontSize = 18.sp)
            Text(title, color = Muted, fontSize = 9.sp, maxLines = 2, minLines = 2)
            Text(formatRupiah(amount), fontSize = 12.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(sub, color = Muted, fontSize = 8.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
    }
}

@Composable
private fun QuickButton(icon: String, label: String, modifier: Modifier, onClick: () -> Unit) {
    Surface(modifier = modifier.height(82.dp).clickable { onClick() }, color = Color(0x99102F28), shape = RoundedCornerShape(16.dp), border = androidx.compose.foundation.BorderStroke(1.dp, Color(0x2877AB95))) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
            Box(Modifier.size(32.dp).clip(CircleShape).background(Color(0xFF18200F)), contentAlignment = Alignment.Center) { Text(icon, color = Lime, fontSize = 16.sp) }
            Spacer(Modifier.height(6.dp))
            Text(label, color = Color(0xFFCBD2BC), fontSize = 9.sp, maxLines = 1)
        }
    }
}

@Composable
private fun MetricBox(label: String, amount: Long, color: Color, modifier: Modifier) {
    Box(modifier.clip(RoundedCornerShape(14.dp)).background(Color(0x9415372F)).padding(10.dp)) {
        Column {
            Text(label, color = Muted, fontSize = 8.sp)
            Text(formatRupiah(amount), color = color, fontSize = 12.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
    }
}

@Composable
private fun LegendDot(color: Color, text: String) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(8.dp).clip(CircleShape).background(color))
        Spacer(Modifier.width(5.dp))
        Text(text, color = Muted, fontSize = 9.sp)
    }
}

@Composable
private fun TransactionsScreen(tx: List<Tx>, onAdd: () -> Unit, onDelete: (Long) -> Unit) {
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(15.dp, 18.dp, 15.dp, 94.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item {
            Text("Transaksi", fontSize = 28.sp, fontWeight = FontWeight.Bold, color = Lime)
            Text("Semua pemasukan, pengeluaran, dan pelunasan.", color = Muted, fontSize = 10.sp)
        }
        item {
            Button(onClick = onAdd, modifier = Modifier.fillMaxWidth().height(48.dp), shape = RoundedCornerShape(15.dp), colors = ButtonDefaults.buttonColors(containerColor = Lime)) {
                Text("＋ Tambah", color = Color(0xFF142000), fontWeight = FontWeight.Bold)
            }
        }
        item {
            GlassCard(Modifier.fillMaxWidth(), RoundedCornerShape(20.dp)) {
                if (tx.isEmpty()) EmptyState("Belum ada transaksi.")
                else tx.sortedByDescending { it.id }.forEach { item ->
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        TransactionRow(item, Modifier.weight(1f))
                        Text("Hapus", color = Red, fontSize = 9.sp, modifier = Modifier.clickable { onDelete(item.id) }.padding(7.dp))
                    }
                }
            }
        }
    }
}

@Composable
private fun TransactionRow(tx: Tx, modifier: Modifier = Modifier) {
    val isIncome = tx.type == "income"
    Row(modifier.fillMaxWidth().padding(horizontal = 2.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(39.dp).clip(RoundedCornerShape(13.dp)).background(Color(0x85193E34)), contentAlignment = Alignment.Center) {
            Text(if (isIncome) "↗" else if (tx.type == "pay") "◇" else "↘", color = if (isIncome) Lime else Red, fontSize = 17.sp)
        }
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) {
            Text(tx.desc, fontSize = 12.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text("${prettyDate(tx.date)} • ${typeName(tx.type)}", color = Muted, fontSize = 9.sp)
        }
        Text((if (isIncome) "+" else "-") + formatRupiah(tx.amount), color = if (isIncome) Lime else Red, fontSize = 11.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun PortfolioScreen(tx: List<Tx>, savings: Long) {
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(15.dp, 18.dp, 15.dp, 94.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item {
            Text("Perkembangan Portofolio", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = Lime)
            Text("7 hari", color = Muted, fontSize = 10.sp)
        }
        item {
            GlassCard(Modifier.fillMaxWidth(), RoundedCornerShape(20.dp)) {
                Column(Modifier.padding(12.dp)) {
                    LineChart(tx, Modifier.fillMaxWidth().height(245.dp))
                    LegendDot(Lime, "Saldo portofolio")
                }
            }
        }
        item {
            val income = tx.filter { it.type == "income" }.sumOf { it.amount }
            val expense = tx.filter { it.type == "expense" }.sumOf { it.amount }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                MetricBox("Pemasukan", income, Lime, Modifier.weight(1f))
                MetricBox("Pengeluaran", expense, Red, Modifier.weight(1f))
                MetricBox("Tabungan", savings, Blue, Modifier.weight(1f))
            }
        }
    }
}

@Composable
private fun LineChart(tx: List<Tx>, modifier: Modifier) {
    val days = (0..6).map { i ->
        Calendar.getInstance().apply { add(Calendar.DAY_OF_YEAR, -6 + i) }.time
    }
    val values = days.map { date ->
        val key = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(date)
        tx.filter { it.date <= key }.sumOf { if (it.type == "income") it.amount else -it.amount }.coerceAtLeast(0)
    }
    val max = maxOf(values.maxOrNull() ?: 1L, 1L).toFloat()
    Canvas(modifier) {
        val left = 8f; val right = size.width - 8f; val top = 14f; val bottom = size.height - 28f
        for (i in 1..4) {
            val y = top + i * (bottom - top) / 5f
            drawLine(Line, Offset(left, y), Offset(right, y), 1f)
        }
        val pts = values.mapIndexed { i, v -> Offset(left + i * (right-left) / 6f, bottom - (v / max) * (bottom-top)) }
        if (pts.size > 1) {
            val area = Path().apply { moveTo(pts.first().x, bottom); pts.forEach { lineTo(it.x, it.y) }; lineTo(pts.last().x, bottom); close() }
            drawPath(area, Brush.verticalGradient(listOf(Lime.copy(alpha=.22f), Color.Transparent)))
            val path = Path().apply { moveTo(pts.first().x, pts.first().y); pts.drop(1).forEach { lineTo(it.x, it.y) } }
            drawPath(path, Lime, style = Stroke(width = 3.2f, cap = StrokeCap.Round))
            pts.forEach { drawCircle(Lime, 4f, it); drawCircle(Bg, 1.8f, it) }
        }
        days.forEachIndexed { i, d ->
            val x = left + i * (right-left) / 6f
            drawContext.canvas.nativeCanvas.drawText(
                SimpleDateFormat("dd", Locale.US).format(d).removePrefix("0"), x, size.height - 6f,
                android.graphics.Paint().apply { color = android.graphics.Color.rgb(113,139,128); textSize = 24f; textAlign = android.graphics.Paint.Align.CENTER; isAntiAlias = true }
            )
        }
    }
}

@Composable
private fun DonutChart(income: Long, expense: Long, pay: Long, modifier: Modifier) {
    val total = maxOf(1L, income + expense + pay)
    Canvas(modifier) {
        val stroke = size.minDimension * .22f
        val diameter = size.minDimension - stroke
        val topLeft = Offset((size.width-diameter)/2, (size.height-diameter)/2)
        val arcSize = androidx.compose.ui.geometry.Size(diameter, diameter)
        var start = -90f
        listOf(income to Lime, expense to Red, pay to Color(0xFF52665C)).forEach { (v,c) ->
            val sweep = 360f * v / total
            drawArc(c, start, sweep.coerceAtLeast(if (v > 0) 4f else 0f), false, topLeft, arcSize, style = Stroke(stroke))
            start += sweep
        }
        drawCircle(Bg, size.minDimension*.27f)
    }
}

@Composable
private fun EmptyState(text: String) {
    Column(Modifier.fillMaxWidth().padding(22.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Text("Belum ada transaksi.", color = Muted, fontSize = 11.sp)
        Text("Tekan + untuk mulai mencatat.", color = Muted, fontSize = 9.sp)
    }
}

@Composable
private fun AddDialog(initialType: String, onDismiss: () -> Unit, onSave: (String, String, Long) -> Unit) {
    var type by remember { mutableStateOf(initialType) }
    var desc by remember { mutableStateOf("") }
    var amount by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss, containerColor = Panel,
        title = { Text("Tambah Transaksi", fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(9.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                    listOf("income" to "Pemasukan", "expense" to "Pengeluaran", "pay" to "Pelunasan").forEach { (key,label) ->
                        FilterChip(selected = type == key, onClick = { type = key }, label = { Text(label, fontSize = 9.sp) }, modifier = Modifier.weight(1f))
                    }
                }
                OutlinedTextField(desc, { desc = it }, label = { Text("Keterangan") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(amount, { amount = it.filter(Char::isDigit) }, label = { Text("Nominal") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            }
        },
        confirmButton = {
            Button(onClick = { val n = amount.toLongOrNull() ?: 0; if (n > 0) onSave(type, desc.ifBlank { "Transaksi" }, n) }, colors = ButtonDefaults.buttonColors(containerColor = Lime)) { Text("Simpan", color = Color(0xFF142000)) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Batal", color = Muted) } }
    )
}

private class FinanceStore(context: Context) {
    private val p = context.getSharedPreferences("keuangan_native", Context.MODE_PRIVATE)
    fun load(): List<Tx> = runCatching {
        val a = JSONArray(p.getString("tx", "[]")); buildList {
            for (i in 0 until a.length()) { val o=a.getJSONObject(i); add(Tx(o.getLong("id"),o.getString("type"),o.getString("desc"),o.getLong("amount"),o.getString("date"))) }
        }
    }.getOrDefault(emptyList())
    fun salary() = p.getLong("salary", 0L)
    fun limit() = p.getLong("limit", 0L)
    fun savings() = p.getLong("savings", 0L)
    fun obligation() = p.getLong("obligation", 0L)
    fun save(list: List<Tx>, salary: Long, limit: Long, savings: Long, obligation: Long) {
        val a=JSONArray(); list.forEach { o -> a.put(JSONObject().apply { put("id",o.id);put("type",o.type);put("desc",o.desc);put("amount",o.amount);put("date",o.date) }) }
        p.edit().putString("tx",a.toString()).putLong("salary",salary).putLong("limit",limit).putLong("savings",savings).putLong("obligation",obligation).apply()
    }
}

private fun todayString() = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
private fun prettyDate(s: String): String = runCatching { SimpleDateFormat("yyyy-MM-dd", Locale.US).parse(s)?.let { SimpleDateFormat("dd MMM yyyy", Locale("id","ID")).format(it) } ?: s }.getOrDefault(s)
private fun typeName(type: String) = when(type) { "income" -> "Pemasukan"; "pay" -> "Pelunasan"; else -> "Pengeluaran" }
private fun formatRupiah(v: Long): String = "Rp " + NumberFormat.getNumberInstance(Locale("id","ID")).format(v)
