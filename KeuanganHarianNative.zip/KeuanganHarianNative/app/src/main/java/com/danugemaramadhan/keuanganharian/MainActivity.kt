package com.danugemaramadhan.keuanganharian

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Bg=Color(0xFF071812); private val Card=Color(0xFF10271F); private val Lime=Color(0xFFC8FF3D); private val Muted=Color(0xFF91A59C)
class MainActivity:ComponentActivity(){override fun onCreate(b:Bundle?){super.onCreate(b);setContent{App()}}}
@Composable fun App(){var tab by remember{mutableStateOf(0)};MaterialTheme(colorScheme=darkColorScheme(background=Bg,surface=Card,primary=Lime,onPrimary=Color.Black,onBackground=Color.White,onSurface=Color.White)){Scaffold(containerColor=Bg,bottomBar={NavigationBar(containerColor=Card){listOf("Beranda","Transaksi","Grafik","Akun").forEachIndexed{i,l->NavigationBarItem(selected=tab==i,onClick={tab=i},icon={Text(listOf("⌂","↕","▥","●")[i])},label={Text(l)})}}}){p->when(tab){0->Home(Modifier.padding(p));1->Transactions(Modifier.padding(p));2->Charts(Modifier.padding(p));else->Account(Modifier.padding(p))}}}}
@Composable fun Home(m:Modifier){LazyColumn(m.fillMaxSize().padding(20.dp),verticalArrangement=Arrangement.spacedBy(14.dp)){item{Text("Keuangan Harian",fontSize=28.sp,fontWeight=FontWeight.Bold);Text("Kelola keuanganmu dengan lebih rapi.",color=Muted)};item{Card(shape=RoundedCornerShape(24.dp)){Column(Modifier.padding(20.dp)){Text("Saldo",color=Muted);Text("Rp 0",fontSize=34.sp,fontWeight=FontWeight.Bold);Spacer(Modifier.height(16.dp));Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){Summary("Pemasukan","Rp 0");Summary("Pengeluaran","Rp 0")}}}};item{Text("Ringkasan 7 Hari",fontSize=20.sp,fontWeight=FontWeight.Bold)};item{Card(shape=RoundedCornerShape(20.dp)){Box(Modifier.fillMaxWidth().height(180.dp),contentAlignment=Alignment.Center){Text("Grafik keuangan",color=Muted)}}}}}
@Composable fun Summary(a:String,b:String){Column{Text(a,color=Muted);Text(b,fontWeight=FontWeight.Bold,fontSize=18.sp)}}
@Composable fun Transactions(m:Modifier){Column(m.fillMaxSize().padding(20.dp)){Text("Transaksi",fontSize=28.sp,fontWeight=FontWeight.Bold);Spacer(Modifier.height(16.dp));Button(onClick={},modifier=Modifier.fillMaxWidth()){Text("+ Tambah Transaksi")};Spacer(Modifier.height(20.dp));Text("Belum ada transaksi.",color=Muted)}}
@Composable fun Charts(m:Modifier){Column(m.fillMaxSize().padding(20.dp)){Text("Grafik",fontSize=28.sp,fontWeight=FontWeight.Bold);Spacer(Modifier.height(16.dp));Card(shape=RoundedCornerShape(20.dp)){Box(Modifier.fillMaxWidth().height(280.dp),contentAlignment=Alignment.Center){Text("Grafik pemasukan & pengeluaran",color=Muted)}}}}
@Composable fun Account(m:Modifier){Column(m.fillMaxSize().padding(20.dp)){Text("Akun",fontSize=28.sp,fontWeight=FontWeight.Bold);Spacer(Modifier.height(20.dp));Card(shape=RoundedCornerShape(20.dp)){Column(Modifier.padding(20.dp)){Text("Keuangan Harian",fontSize=20.sp,fontWeight=FontWeight.Bold);Text("Aplikasi Android native",color=Muted);Spacer(Modifier.height(18.dp));Button(onClick={},modifier=Modifier.fillMaxWidth()){Text("Login Google")};Spacer(Modifier.height(10.dp));OutlinedButton(onClick={},modifier=Modifier.fillMaxWidth()){Text("Sinkronkan")}}}}}
