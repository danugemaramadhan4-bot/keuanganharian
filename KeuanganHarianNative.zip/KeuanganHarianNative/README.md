# Keuangan Harian Native
Versi native Android 1.1.0 dengan UI yang diperbaiki, transaksi lokal, ringkasan, grafik 7 hari, dan navigasi native.

Google/Firebase sync belum diaktifkan pada build ini.
