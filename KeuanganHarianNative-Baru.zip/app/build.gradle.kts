plugins {
    id("com.android.application")
}

android {
    namespace = "com.danugemaramadhan.keuanganharian"
    compileSdk = 37

    defaultConfig {
        applicationId = "com.danugemaramadhan.keuanganharian"
        minSdk = 26
        targetSdk = 37
        versionCode = 1
        versionName = "1.0"
    }
}
