package com.danugemaramadhan.keuanganharian;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.text.InputType;
import android.view.Gravity;
import android.widget.*;

public class MainActivity extends Activity {
    LinearLayout root, content;
    long total = 0;
    final int GREEN = Color.rgb(139,195,74);
    final int DARK = Color.rgb(11,21,16);
    final int CARD = Color.rgb(22,36,28);

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        showHome();
    }

    TextView text(String s, float size) {
        TextView v = new TextView(this);
        v.setText(s);
        v.setTextColor(Color.WHITE);
        v.setTextSize(size);
        v.setPadding(20,16,20,16);
        return v;
    }

    Button button(String s) {
        Button b = new Button(this);
        b.setText(s);
        b.setTextColor(Color.WHITE);
        b.setAllCaps(false);
        b.setBackgroundColor(CARD);
        return b;
    }

    void base() {
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(DARK);

        TextView title = text("Keuangan Harian", 24);
        title.setTextColor(GREEN);
        title.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        title.setGravity(Gravity.CENTER_VERTICAL);
        root.addView(title, new LinearLayout.LayoutParams(-1, 70));

        content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);

        ScrollView scroll = new ScrollView(this);
        scroll.addView(content);
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));

        LinearLayout nav = new LinearLayout(this);
        String[] names = {"Beranda", "Transaksi", "Akun"};
        for (String name : names) {
            Button b = button(name);
            b.setOnClickListener(v -> {
                if (name.equals("Beranda")) showHome();
                else if (name.equals("Transaksi")) showTransactions();
                else showAccount();
            });
            nav.addView(b, new LinearLayout.LayoutParams(0, 64, 1));
        }
        root.addView(nav);
        setContentView(root);
    }

    void showHome() {
        base();
        content.addView(text("Saldo Saat Ini", 18));
        TextView saldo = text("Rp " + rupiah(total), 32);
        saldo.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        content.addView(saldo);

        TextView info = text("Native Android • data dasar tersimpan di aplikasi", 14);
        info.setTextColor(Color.LTGRAY);
        content.addView(info);

        Button add = button("+ Tambah Transaksi");
        add.setTextColor(Color.BLACK);
        add.setBackgroundColor(GREEN);
        add.setOnClickListener(v -> showAdd());
        content.addView(add, new LinearLayout.LayoutParams(-1, 60));

        TextView chart = text("Ringkasan 7 Hari\nBelum ada transaksi.", 18);
        chart.setBackgroundColor(CARD);
        content.addView(chart);
    }

    void showTransactions() {
        base();
        content.addView(text("Transaksi", 24));
        Button add = button("+ Tambah");
        add.setOnClickListener(v -> showAdd());
        content.addView(add);
        content.addView(text(
            total == 0 ? "Belum ada transaksi." : "Saldo: Rp " + rupiah(total), 18
        ));
    }

    void showAdd() {
        base();
        content.addView(text("Tambah Transaksi", 24));

        EditText amount = new EditText(this);
        amount.setHint("Nominal");
        amount.setInputType(InputType.TYPE_CLASS_NUMBER);
        amount.setTextColor(Color.WHITE);
        amount.setHintTextColor(Color.GRAY);
        content.addView(amount);

        Button income = button("Pemasukan");
        Button expense = button("Pengeluaran");

        income.setOnClickListener(v -> {
            total += read(amount);
            showHome();
        });
        expense.setOnClickListener(v -> {
            total -= read(amount);
            showHome();
        });

        content.addView(income);
        content.addView(expense);
    }

    long read(EditText e) {
        try { return Long.parseLong(e.getText().toString()); }
        catch (Exception ignored) { return 0; }
    }

    String rupiah(long n) {
        return String.format(java.util.Locale.US, "%,d", n).replace(',', '.');
    }

    void showAccount() {
        base();
        content.addView(text("Akun", 24));
        content.addView(text(
            "Keuangan Harian\nVersi 1.0\n\nLogin Google dan sinkronisasi cloud akan dibuat setelah APK dasar berhasil.",
            17
        ));
    }
}
