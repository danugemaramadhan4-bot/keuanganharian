# Keuangan Harian Native

Versi build pertama adalah Android native murni.
Tidak menggunakan WebView, PWA, atau GitHub Pages.

Tahap berikutnya setelah APK berhasil:
- penyimpanan transaksi permanen
- login Google
- sinkronisasi Firebase
