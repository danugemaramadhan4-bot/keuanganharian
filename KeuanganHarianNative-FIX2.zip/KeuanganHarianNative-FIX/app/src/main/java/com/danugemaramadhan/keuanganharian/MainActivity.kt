package com.danugemaramadhan.keuanganharian

import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.json.JSONArray
import org.json.JSONObject
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

private val Bg = Color(0xFF07120D)
private val Panel = Color(0xFF101F17)
private val Panel2 = Color(0xFF14271D)
private val Lime = Color(0xFF8DCE43)
private val LimeSoft = Color(0xFFB7ED6A)
private val Muted = Color(0xFF9BAAA2)
private val Red = Color(0xFFFF6B6B)
private val White = Color(0xFFF4F7F4)

private val AppColors = darkColorScheme(
    background = Bg,
    surface = Panel,
    primary = Lime,
    onPrimary = Color(0xFF142000),
    onBackground = White,
    onSurface = White
)

data class FinanceTx(
    val type: String,
    val description: String,
    val amount: Long,
    val date: String
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.rgb(7, 18, 13)
        window.navigationBarColor = android.graphics.Color.rgb(7, 18, 13)

        setContent {
            MaterialTheme(colorScheme = AppColors) {
                KeuanganHarianApp(applicationContext)
            }
        }
    }
}

@Composable
private fun KeuanganHarianApp(context: Context) {
    var splash by rememberSaveable { mutableStateOf(true) }
    var tab by rememberSaveable { mutableStateOf(0) }
    var showAdd by remember { mutableStateOf(false) }
    val tx = remember {
        mutableStateListOf<FinanceTx>().apply { addAll(loadTransactions(context)) }
    }

    LaunchedEffect(Unit) {
        kotlinx.coroutines.delay(700)
        splash = false
    }

    if (splash) {
        SplashScreen()
        return
    }

    val income = tx.filter { it.type == "income" }.sumOf { it.amount }
    val expense = tx.filter { it.type == "expense" }.sumOf { it.amount }
    val balance = income - expense

    Scaffold(
        containerColor = Bg,
        bottomBar = {
            BottomNav(tab = tab, onTab = { tab = it })
        }
    ) { pad ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Bg)
                .padding(pad)
        ) {
            when (tab) {
                0 -> HomeScreen(
                    balance = balance,
                    income = income,
                    expense = expense,
                    tx = tx,
                    onAdd = { showAdd = true }
                )
                1 -> TransactionsScreen(
                    tx = tx,
                    onAdd = { showAdd = true },
                    onDelete = { item ->
                        tx.remove(item)
                        saveTransactions(context, tx)
                    }
                )
                2 -> PortfolioScreen(tx = tx, balance = balance)
                else -> AccountScreen(txCount = tx.size)
            }
        }
    }

    if (showAdd) {
        AddTransactionDialog(
            onDismiss = { showAdd = false },
            onSave = { type, desc, amount ->
                val item = FinanceTx(type, desc.ifBlank { "Transaksi" }, amount, todayKey())
                tx.add(0, item)
                saveTransactions(context, tx)
                showAdd = false
            }
        )
    }
}

@Composable
private fun SplashScreen() {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Bg),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Box(
                modifier = Modifier
                    .size(78.dp)
                    .clip(RoundedCornerShape(22.dp))
                    .background(Lime),
                contentAlignment = Alignment.Center
            ) {
                Text("Rp", color = Color(0xFF152000), fontSize = 28.sp, fontWeight = FontWeight.Black)
            }
            Spacer(Modifier.height(18.dp))
            Text("Keuangan Harian", color = LimeSoft, fontSize = 27.sp, fontWeight = FontWeight.Bold)
            Text("Kelola uang lebih rapi setiap hari", color = Muted, fontSize = 13.sp)
        }
    }
}

@Composable
private fun HomeScreen(
    balance: Long,
    income: Long,
    expense: Long,
    tx: List<FinanceTx>,
    onAdd: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 18.dp, vertical = 16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text("Halo, Kak! 👋", color = White, fontSize = 14.sp)
                Text("Keuangan pribadi", color = Muted, fontSize = 12.sp)
            }
            Box(
                modifier = Modifier
                    .size(42.dp)
                    .clip(RoundedCornerShape(14.dp))
                    .background(Panel2),
                contentAlignment = Alignment.Center
            ) {
                Text("KH", color = LimeSoft, fontWeight = FontWeight.Bold)
            }
        }

        Spacer(Modifier.height(18.dp))

        Card(
            colors = CardDefaults.cardColors(containerColor = Panel2),
            shape = RoundedCornerShape(22.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(
                        Brush.linearGradient(listOf(Color(0xFF173321), Panel2))
                    )
                    .padding(20.dp)
            ) {
                Text("TOTAL SALDO", color = Muted, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(5.dp))
                Text(rp(balance), color = White, fontSize = 31.sp, fontWeight = FontWeight.Black)
                Spacer(Modifier.height(6.dp))
                Text("Saldo tersedia dari transaksi tersimpan", color = Muted, fontSize = 12.sp)
            }
        }

        Spacer(Modifier.height(14.dp))

        Button(
            onClick = onAdd,
            modifier = Modifier.fillMaxWidth().height(52.dp),
            shape = RoundedCornerShape(16.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Lime)
        ) {
            Text("＋ Tambah Transaksi", fontWeight = FontWeight.Bold, color = Color(0xFF142000))
        }

        Spacer(Modifier.height(20.dp))
        SectionTitle("Kartu Keuangan")

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            StatCard("Pemasukan", income, Lime, "↗")
            StatCard("Pengeluaran", expense, Red, "↘")
            StatCard("Sisa", balance, if (balance >= 0) Lime else Red, "◎")
        }

        Spacer(Modifier.height(22.dp))
        SectionTitle("Grafik Keuangan 7 Hari")
        FinanceChart(tx)

        Spacer(Modifier.height(22.dp))
        SectionTitle("Diagram Keuangan")
        DonutCard(income = income, expense = expense)

        Spacer(Modifier.height(22.dp))
        SectionTitle("Transaksi Terbaru")

        Card(
            colors = CardDefaults.cardColors(containerColor = Panel),
            shape = RoundedCornerShape(18.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            if (tx.isEmpty()) {
                EmptyState("Belum ada transaksi.\nTekan “Tambah Transaksi” untuk mulai.")
            } else {
                Column(Modifier.padding(horizontal = 16.dp, vertical = 8.dp)) {
                    tx.take(5).forEachIndexed { index, item ->
                        TransactionRow(item)
                        if (index < minOf(4, tx.size - 1)) {
                            Divider(color = Color(0xFF20352A))
                        }
                    }
                }
            }
        }
        Spacer(Modifier.height(20.dp))
    }
}

@Composable
private fun StatCard(title: String, value: Long, color: Color, icon: String) {
    Card(
        colors = CardDefaults.cardColors(containerColor = Panel),
        shape = RoundedCornerShape(18.dp),
        modifier = Modifier.width(185.dp)
    ) {
        Column(Modifier.padding(15.dp)) {
            Text(icon, color = color, fontSize = 22.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(8.dp))
            Text(title, color = Muted, fontSize = 11.sp)
            Spacer(Modifier.height(3.dp))
            Text(rp(value), color = color, fontSize = 17.sp, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun FinanceChart(tx: List<FinanceTx>) {
    val days = remember(tx) { last7Days() }
    val values = days.map { day ->
        tx.filter { it.date == day }.sumOf { if (it.type == "income") it.amount else -it.amount }
    }
    val maxAbs = maxOf(1L, values.maxOfOrNull { kotlin.math.abs(it) } ?: 1L).toFloat()

    Card(
        colors = CardDefaults.cardColors(containerColor = Panel),
        shape = RoundedCornerShape(18.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(Modifier.padding(16.dp)) {
            Text("Arus kas", color = Muted, fontSize = 11.sp)
            Spacer(Modifier.height(8.dp))
            Canvas(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(190.dp)
            ) {
                val left = 8f
                val right = size.width - 8f
                val top = 16f
                val bottom = size.height - 28f
                val step = (right - left) / 6f

                drawLine(Color(0xFF294236), Offset(left, (top + bottom) / 2), Offset(right, (top + bottom) / 2), 1f)

                val path = Path()
                values.forEachIndexed { i, v ->
                    val x = left + step * i
                    val y = ((top + bottom) / 2f) - (v / maxAbs) * ((bottom - top) / 2f)
                    if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
                }
                drawPath(path, LimeSoft, style = Stroke(width = 5f, cap = StrokeCap.Round))
                values.forEachIndexed { i, v ->
                    val x = left + step * i
                    val y = ((top + bottom) / 2f) - (v / maxAbs) * ((bottom - top) / 2f)
                    drawCircle(if (v >= 0) LimeSoft else Red, 5f, Offset(x, y))
                }
            }
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                days.forEach { day ->
                    Text(
                        day.takeLast(2),
                        color = Muted,
                        fontSize = 9.sp,
                        modifier = Modifier.width(34.dp),
                        textAlign = TextAlign.Center
                    )
                }
            }
        }
    }
}

@Composable
private fun DonutCard(income: Long, expense: Long) {
    val total = (income + expense).coerceAtLeast(1)
    val incomeAngle = income.toFloat() / total * 360f
    Card(
        colors = CardDefaults.cardColors(containerColor = Panel),
        shape = RoundedCornerShape(18.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(18.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(Modifier.size(120.dp), contentAlignment = Alignment.Center) {
                Canvas(Modifier.fillMaxSize()) {
                    val stroke = 18f
                    drawArc(
                        Lime,
                        -90f,
                        incomeAngle,
                        false,
                        style = Stroke(stroke)
                    )
                    drawArc(
                        Red,
                        -90f + incomeAngle,
                        360f - incomeAngle,
                        false,
                        style = Stroke(stroke)
                    )
                }
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(rp(income - expense), color = White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    Text("bersih", color = Muted, fontSize = 9.sp)
                }
            }
            Spacer(Modifier.width(18.dp))
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Legend("Pemasukan", income, Lime)
                Legend("Pengeluaran", expense, Red)
            }
        }
    }
}

@Composable
private fun Legend(label: String, value: Long, color: Color) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(10.dp).clip(RoundedCornerShape(3.dp)).background(color))
        Spacer(Modifier.width(8.dp))
        Column {
            Text(label, color = Muted, fontSize = 10.sp)
            Text(rp(value), color = White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun TransactionsScreen(
    tx: List<FinanceTx>,
    onAdd: () -> Unit,
    onDelete: (FinanceTx) -> Unit
) {
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(18.dp)
    ) {
        ScreenHeader("Transaksi", "Catat semua pemasukan dan pengeluaran")
        Spacer(Modifier.height(14.dp))
        Button(
            onClick = onAdd,
            modifier = Modifier.fillMaxWidth().height(50.dp),
            shape = RoundedCornerShape(15.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Lime)
        ) {
            Text("＋ Tambah Transaksi", color = Color(0xFF142000), fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.height(16.dp))

        Card(
            colors = CardDefaults.cardColors(containerColor = Panel),
            shape = RoundedCornerShape(18.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            if (tx.isEmpty()) {
                EmptyState("Belum ada transaksi.")
            } else {
                Column(Modifier.padding(horizontal = 16.dp)) {
                    tx.forEachIndexed { index, item ->
                        Row(
                            Modifier.fillMaxWidth().padding(vertical = 13.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                Modifier.size(40.dp).clip(RoundedCornerShape(12.dp))
                                    .background(if (item.type == "income") Color(0xFF1D3823) else Color(0xFF3A2224)),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(if (item.type == "income") "↗" else "↘",
                                    color = if (item.type == "income") LimeSoft else Red,
                                    fontSize = 18.sp)
                            }
                            Spacer(Modifier.width(12.dp))
                            Column(Modifier.weight(1f)) {
                                Text(item.description, color = White, fontWeight = FontWeight.SemiBold)
                                Text(formatDate(item.date), color = Muted, fontSize = 10.sp)
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Text(
                                    (if (item.type == "income") "+" else "-") + rp(item.amount),
                                    color = if (item.type == "income") LimeSoft else Red,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 12.sp
                                )
                                TextButton(
                                    onClick = { onDelete(item) },
                                    contentPadding = androidx.compose.foundation.layout.PaddingValues(0.dp)
                                ) {
                                    Text("Hapus", color = Muted, fontSize = 10.sp)
                                }
                            }
                        }
                        if (index < tx.lastIndex) Divider(color = Color(0xFF20352A))
                    }
                }
            }
        }
    }
}

@Composable
private fun PortfolioScreen(tx: List<FinanceTx>, balance: Long) {
    val income = tx.filter { it.type == "income" }.sumOf { it.amount }
    val expense = tx.filter { it.type == "expense" }.sumOf { it.amount }
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(18.dp)
    ) {
        ScreenHeader("Portofolio", "Ringkasan kondisi keuangan")
        Spacer(Modifier.height(16.dp))
        Card(
            colors = CardDefaults.cardColors(containerColor = Panel2),
            shape = RoundedCornerShape(20.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(Modifier.padding(20.dp)) {
                Text("TOTAL PORTOFOLIO", color = Muted, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                Text(rp(balance), color = White, fontSize = 29.sp, fontWeight = FontWeight.Black)
                Text("Saldo tersedia + hasil transaksi", color = Muted, fontSize = 11.sp)
            }
        }
        Spacer(Modifier.height(16.dp))
        SectionTitle("Komposisi")
        Spacer(Modifier.height(8.dp))
        InfoCard("💵 Pemasukan", income, Lime)
        Spacer(Modifier.height(8.dp))
        InfoCard("💸 Pengeluaran", expense, Red)
        Spacer(Modifier.height(8.dp))
        InfoCard("📊 Saldo bersih", balance, if (balance >= 0) Lime else Red)
        Spacer(Modifier.height(18.dp))
        SectionTitle("Perkembangan 7 Hari")
        FinanceChart(tx)
    }
}

@Composable
private fun InfoCard(label: String, value: Long, color: Color) {
    Card(
        colors = CardDefaults.cardColors(containerColor = Panel),
        shape = RoundedCornerShape(16.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            Modifier.fillMaxWidth().padding(16.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(label, color = White)
            Text(rp(value), color = color, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun AccountScreen(txCount: Int) {
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(18.dp)
    ) {
        ScreenHeader("Akun", "Pengaturan aplikasi")
        Spacer(Modifier.height(16.dp))
        Card(
            colors = CardDefaults.cardColors(containerColor = Panel),
            shape = RoundedCornerShape(18.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(Modifier.padding(18.dp)) {
                Text("Keuangan Harian", color = White, fontSize = 19.sp, fontWeight = FontWeight.Bold)
                Text("Versi native Android 1.1", color = Muted, fontSize = 11.sp)
                Spacer(Modifier.height(16.dp))
                SettingRow("Penyimpanan", "Data tersimpan di perangkat")
                SettingRow("Mode", "Offline / lokal")
                SettingRow("Total transaksi", "$txCount transaksi")
                SettingRow("Sinkronisasi cloud", "Disiapkan untuk tahap berikutnya")
            }
        }
        Spacer(Modifier.height(14.dp))
        Card(
            colors = CardDefaults.cardColors(containerColor = Panel2),
            shape = RoundedCornerShape(18.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Text(
                "Tip: gunakan Backup secara berkala setelah fitur backup ditambahkan.",
                color = Muted,
                fontSize = 11.sp,
                modifier = Modifier.padding(16.dp)
            )
        }
    }
}

@Composable
private fun SettingRow(title: String, value: String) {
    Column(Modifier.padding(vertical = 8.dp)) {
        Text(title, color = White, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
        Text(value, color = Muted, fontSize = 10.sp)
    }
}

@Composable
private fun ScreenHeader(title: String, subtitle: String) {
    Column {
        Text(title, color = White, fontSize = 27.sp, fontWeight = FontWeight.Black)
        Text(subtitle, color = Muted, fontSize = 12.sp)
    }
}

@Composable
private fun SectionTitle(title: String) {
    Text(title, color = White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
}

@Composable
private fun TransactionRow(item: FinanceTx) {
    Row(
        Modifier.fillMaxWidth().padding(vertical = 13.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier.size(38.dp).clip(RoundedCornerShape(11.dp))
                .background(if (item.type == "income") Color(0xFF1D3823) else Color(0xFF3A2224)),
            contentAlignment = Alignment.Center
        ) {
            Text(if (item.type == "income") "↗" else "↘",
                color = if (item.type == "income") LimeSoft else Red)
        }
        Spacer(Modifier.width(11.dp))
        Column(Modifier.weight(1f)) {
            Text(item.description, color = White, fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
            Text(formatDate(item.date), color = Muted, fontSize = 9.sp)
        }
        Text(
            (if (item.type == "income") "+" else "-") + rp(item.amount),
            color = if (item.type == "income") LimeSoft else Red,
            fontWeight = FontWeight.Bold,
            fontSize = 11.sp
        )
    }
}

@Composable
private fun EmptyState(text: String) {
    Text(
        text,
        color = Muted,
        fontSize = 12.sp,
        textAlign = TextAlign.Center,
        modifier = Modifier.fillMaxWidth().padding(28.dp)
    )
}

@Composable
private fun BottomNav(tab: Int, onTab: (Int) -> Unit) {
    Surface(color = Color(0xFF0D1B14), shadowElevation = 10.dp) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.SpaceEvenly
        ) {
            NavItem("Beranda", "⌂", tab == 0) { onTab(0) }
            NavItem("Transaksi", "≡", tab == 1) { onTab(1) }
            NavItem("Portofolio", "◈", tab == 2) { onTab(2) }
            NavItem("Akun", "⚙", tab == 3) { onTab(3) }
        }
    }
}

@Composable
private fun NavItem(label: String, icon: String, selected: Boolean, onClick: () -> Unit) {
    TextButton(
        onClick = onClick,
        modifier = Modifier.width(92.dp),
        colors = ButtonDefaults.textButtonColors(
            contentColor = if (selected) LimeSoft else Muted
        )
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(icon, fontSize = 18.sp)
            Text(label, fontSize = 9.sp, fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal)
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun AddTransactionDialog(
    onDismiss: () -> Unit,
    onSave: (String, String, Long) -> Unit
) {
    var type by rememberSaveable { mutableStateOf("expense") }
    var description by rememberSaveable { mutableStateOf("") }
    var amountText by rememberSaveable { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Panel2,
        title = { Text("Tambah Transaksi", color = White, fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(
                        onClick = { type = "income" },
                        colors = ButtonDefaults.outlinedButtonColors(
                            containerColor = if (type == "income") Color(0xFF274C2C) else Color.Transparent,
                            contentColor = LimeSoft
                        )
                    ) { Text("Pemasukan") }
                    OutlinedButton(
                        onClick = { type = "expense" },
                        colors = ButtonDefaults.outlinedButtonColors(
                            containerColor = if (type == "expense") Color(0xFF4A2528) else Color.Transparent,
                            contentColor = Red
                        )
                    ) { Text("Pengeluaran") }
                }
                OutlinedTextField(
                    value = description,
                    onValueChange = { description = it },
                    singleLine = true,
                    label = { Text("Keterangan") },
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = amountText,
                    onValueChange = { amountText = it.filter(Char::isDigit) },
                    singleLine = true,
                    label = { Text("Nominal") },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val amount = amountText.toLongOrNull() ?: 0L
                    if (amount > 0) onSave(type, description, amount)
                },
                colors = ButtonDefaults.buttonColors(containerColor = Lime)
            ) {
                Text("Simpan", color = Color(0xFF142000), fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Batal", color = Muted) }
        }
    )
}

private fun rp(value: Long): String {
    val f = NumberFormat.getNumberInstance(Locale("id", "ID"))
    return "Rp ${f.format(value.coerceAtLeast(0L))}"
}

private fun todayKey(): String =
    SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())

private fun formatDate(key: String): String {
    return try {
        val d = SimpleDateFormat("yyyy-MM-dd", Locale.US).parse(key) ?: Date()
        SimpleDateFormat("dd MMM yyyy", Locale("id", "ID")).format(d)
    } catch (_: Exception) {
        key
    }
}

private fun last7Days(): List<String> {
    val result = mutableListOf<String>()
    val cal = Calendar.getInstance()
    cal.add(Calendar.DAY_OF_YEAR, -6)
    repeat(7) {
        result.add(SimpleDateFormat("yyyy-MM-dd", Locale.US).format(cal.time))
        cal.add(Calendar.DAY_OF_YEAR, 1)
    }
    return result
}

private fun loadTransactions(context: Context): List<FinanceTx> {
    return try {
        val raw = context.getSharedPreferences("keuangan", Context.MODE_PRIVATE)
            .getString("transactions", "[]") ?: "[]"
        val arr = JSONArray(raw)
        buildList {
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                add(
                    FinanceTx(
                        o.optString("type", "expense"),
                        o.optString("description", "Transaksi"),
                        o.optLong("amount", 0L),
                        o.optString("date", todayKey())
                    )
                )
            }
        }
    } catch (_: Exception) {
        emptyList()
    }
}

private fun saveTransactions(context: Context, tx: List<FinanceTx>) {
    val arr = JSONArray()
    tx.forEach {
        arr.put(
            JSONObject().apply {
                put("type", it.type)
                put("description", it.description)
                put("amount", it.amount)
                put("date", it.date)
            }
        )
    }
    context.getSharedPreferences("keuangan", Context.MODE_PRIVATE)
        .edit()
        .putString("transactions", arr.toString())
        .apply()
}
