# Keuangan Harian Native - UI FIX
Native Android Kotlin + Jetpack Compose.
Tampilan diperbaiki agar menyerupai desain Keuangan Harian: dashboard, kartu keuangan,
grafik 7 hari, diagram, transaksi, portofolio, akun, dan bottom navigation.
Build: `gradle assembleDebug`
